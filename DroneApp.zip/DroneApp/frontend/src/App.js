import React, { useState, useEffect } from 'react';
import axios from 'axios';

function App() {
  const [telemetry, setTelemetry] = useState([]);
  const [formData, setFormData] = useState({
    latitude: '', longitude: '', altitude: '', speed: '', battery: ''
  });

  const fetchData = async () => {
    try {
      // Menggunakan localhost agar stabil di WSL
      const response = await axios.get('http://localhost:5000/api/telemetry');
      setTelemetry(response.data);
    } catch (error) { console.error("Gagal mengambil data", error); }
  };

  useEffect(() => { fetchData(); }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await axios.post('http://localhost:5000/api/telemetry', formData);
      // Reset form setelah sukses submit agar angka "menghilang" dari kotak input tapi muncul di tabel
      setFormData({ latitude: '', longitude: '', altitude: '', speed: '', battery: '' });
      fetchData(); // Panggil data terbaru untuk memperbarui tabel
    } catch (error) { alert("Gagal menyimpan data!"); }
  };

  return (
    <div style={{ padding: '20px', fontFamily: 'sans-serif' }}>
      <h1>🚁 Drone Telemetry Dashboard</h1>
      
      {/* FORM DENGAN 5 INPUT SESUAI DATABASE */}
      <form onSubmit={handleSubmit} style={{ marginBottom: '20px', display: 'flex', gap: '10px', flexWrap: 'wrap' }}>
        <input type="number" step="any" placeholder="Lat" value={formData.latitude} onChange={e => setFormData({...formData, latitude: e.target.value})} required />
        <input type="number" step="any" placeholder="Long" value={formData.longitude} onChange={e => setFormData({...formData, longitude: e.target.value})} required />
        <input type="number" step="any" placeholder="Alt" value={formData.altitude} onChange={e => setFormData({...formData, altitude: e.target.value})} required />
        <input type="number" step="any" placeholder="Speed" value={formData.speed} onChange={e => setFormData({...formData, speed: e.target.value})} required />
        <input type="number" placeholder="Batt %" value={formData.battery} onChange={e => setFormData({...formData, battery: e.target.value})} required />
        <button type="submit" style={{ cursor: 'pointer' }}>Submit</button>
      </form>

      {/* ALGORITMA TABEL UNTUK MENAMPILKAN OUTPUT */}
      <h3>Daftar Telemetri Terdeteksi</h3>
      <table border="1" style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
        <thead style={{ backgroundColor: '#f0f0f0' }}>
          <tr>
            <th>ID</th><th>Latitude</th><th>Longitude</th><th>Altitude</th><th>Speed</th><th>Battery</th>
          </tr>
        </thead>
        <tbody>
          {telemetry.length > 0 ? telemetry.map((item) => (
            <tr key={item.id}>
              <td>{item.id}</td>
              <td>{item.latitude}</td>
              <td>{item.longitude}</td>
              <td>{item.altitude} m</td>
              <td>{item.speed} m/s</td>
              <td style={{ fontWeight: 'bold' }}>{item.battery}%</td>
            </tr>
          )) : (
            <tr><td colSpan="6" style={{ textAlign: 'center', padding: '10px' }}>Belum ada data di database.</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default App;