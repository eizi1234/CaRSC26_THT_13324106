from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS

app = Flask(__name__)
CORS(app) # Agar Frontend React bisa mengakses Backend ini

# Setup Database SQLite (file sederhana bernama drone.db)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///drone.db'
db = SQLAlchemy(app)

# Tabel Database
class Telemetry(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    altitude = db.Column(db.Float, nullable=False)
    speed = db.Column(db.Float, nullable=False)
    battery = db.Column(db.Integer, nullable=False)

# Membuat database secara otomatis
with app.app_context():
    db.create_all()

# "Pintu" untuk mengambil semua data (Read)
@app.route('/api/telemetry', methods=['GET'])
def get_telemetry():
    data = Telemetry.query.all()
    output = []
    for item in data:
        output.append({
            "id": item.id, "latitude": item.latitude, "longitude": item.longitude,
            "altitude": item.altitude, "speed": item.speed, "battery": item.battery
        })
    return jsonify(output)

# "Pintu" untuk menambah data baru (Create)
@app.route('/api/telemetry', methods=['POST'])
def add_telemetry():
    data = request.json
    new_entry = Telemetry(
        latitude=data['latitude'], longitude=data['longitude'],
        altitude=data['altitude'], speed=data['speed'], battery=data['battery']
    )
    db.session.add(new_entry)
    db.session.commit()
    return jsonify({"message": "Data berhasil disimpan!"})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)